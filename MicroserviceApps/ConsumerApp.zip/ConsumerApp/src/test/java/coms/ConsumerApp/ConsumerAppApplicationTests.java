package coms.ConsumerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
