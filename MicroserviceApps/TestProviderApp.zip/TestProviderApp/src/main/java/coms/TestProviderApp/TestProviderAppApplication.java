package coms.TestProviderApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestProviderAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestProviderAppApplication.class, args);
	}

}
