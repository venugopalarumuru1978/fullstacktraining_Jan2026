package coms.EurekaServerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
